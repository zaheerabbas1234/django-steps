from django.shortcuts import render, redirect
from django.contrib.auth import logout

# Simulated user database (Dictionary)
users = {
    "admin": "admin123"  # Predefined user for testing
}

# Home Page
def home(request):
    user = request.session.get('user')  # Get logged-in user from session
    return render(request, 'home.html', {'user': user})

# Register Page
def register(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        if username in users:
            return render(request, 'register.html', {'error': 'User already exists!'})

        users[username] = password  # Store user in dictionary
        request.session['user'] = username  # Authenticate user using session
        return redirect('home')

    return render(request, 'register.html')

# Login Page
def login_view(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Authenticate by checking dictionary
        if users.get(username) == password:
            request.session['user'] = username  # Store username in session
            return redirect('home')

        return render(request, 'login.html', {'error': 'Invalid credentials!'})

    return render(request, 'login.html')

# Logout Page
def logout_view(request):
    request.session.flush()  # Clear session data (logout user)
    return redirect('home')
