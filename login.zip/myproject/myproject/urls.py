from django.contrib import admin
from django.urls import path
from myapp import views  # Import views from myapp

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),  # Home Page
    path('register/', views.register, name='register'),  # Registration Page
    path('login/', views.login_view, name='login'),  # Login Page
    path('logout/', views.logout_view, name='logout'),  # Logout Page
]
